export class Admin {
      id:number;
      name:string;
      pwd :String
}
